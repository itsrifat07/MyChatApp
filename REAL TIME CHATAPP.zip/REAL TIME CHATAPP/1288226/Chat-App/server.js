const express = require("express");
const http = require("http");
const socket = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = socket(server);

app.use(express.static(__dirname)); 

io.on("connection", (socket) => {
  socket.on("disconnect", () => {
    io.emit("chat message", "server", socket.user + " disconnected!", getTime());
    console.log(socket.user + " disconnected");
  });

  socket.on("start", (user) => {
    socket.user = user;
    io.emit("chat message", "server", socket.user + " connected", getTime());
    console.log(socket.user + " connected");
  });

  socket.on("chat message", (msg) => {
    console.log(socket.user + " : " + msg);
    io.emit("chat message", socket.user, msg, getTime());
  });

  socket.on("file share", (msg) => {
    console.log(socket.user + " shared a file");
    io.emit("file share", socket.user, msg, getTime());
  });
});

app.get("/", (req, res) => {
  res.sendFile(__dirname + "/app.html");
});

function getTime() {
  return new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

const PORT = process.env.PORT || 8000;
server.listen(PORT, () => {
   console.log(`Server running on http://localhost:${PORT}`);
});

